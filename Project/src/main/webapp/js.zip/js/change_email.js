/**
 * 사용자가 이메일 입력 시 도메인을 선택하면 자동으로 세팅하기
    change+email.js 자바스크립트 파일
 
 MemberForm에서 객체 받아옴
 */
 
 function change_email(){
   var email_add= document.getElementById("email_add");
   var email_sel= document.getElementById("email_sel");

   //사용자가 선택한 옵션의 순서와 값 구하기
         //select개체
   var idx = email_sel.options.selectedIndex;
   var val =email_sel.options[idx].value;
   
   email_add.value = val;
   
   
 function conform_email(){
	var email_add= document.getElementById("email_add");
    var email_id= document.getElementById("email_id");
    
   var email;
     email.value = email.add.value+email_id.value;
}  



}